// 配置服务器相关信息
export default {
    host: 'http://localhost:3000',
    mobileHost: 'http://xmwmfr.natappfree.cc',
}