// pages/search/search.js
import request from '../../utils/request'
import PubSub from 'pubsub-js'
let inSend = false
Page({

    /**
     * 页面的初始数据
     */
    data: {
        placeholderContent: '', // 默认搜索内容
        hotList: [], // 热搜榜数据
        search: [], // 搜索显示类容
        searchContent: '', // 用户输入的表单项数据
        searchList: '', // 用户搜索的模糊数据
        historyList: [], // 用户搜索历史记录
        index: 0, //初始化音乐下标
        i: 1, // 标识页面
        block: true, // 列表显示与隐藏
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        this.getInitData()
        this.getSearchHistory()
            // 订阅来自songDetail页面发布的消息
        let index = this.data.index
        PubSub.subscribe('search', (msg, type) => {
            let searchList = this.data.searchList
            if (type === 'pre') { // 上一首
                (index === 0) && (index = searchList.length)
                index -= 1
            } else if (type === 'next') { // 下一首
                (index === searchList.length - 1) && (index = -1)
                index += 1
            } else {
                index = this.getRandom(0, searchList.length - 1)
            }

            // 更新下标
            this.setData({
                index
            })
            let musicId = searchList[index].id
                // 将musicId回传给songDetail页面
            PubSub.publish('musicId', musicId)
        })
    },
    // 随机函数
    getRandom(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min
    },
    // 获取初始化数据
    async getInitData() {
        let placeholderData = await request('/search/default')
        let hotListData = await request('/search/hot/detail')
        this.setData({
            placeholderContent: placeholderData.data.showKeyword,
            hotList: hotListData.data
        })
    },
    // 获取本地历史记录的功能函数
    getSearchHistory() {
        let historyList = wx.getStorageSync('searchHistory')
        if (historyList) {
            this.setData({
                historyList
            })
        }
    },
    // 表单项内容发送改变的回调
    handleInputChange(event) {
        this.setData({
            searchContent: event.detail.value.trim(),
        })
        if (inSend) {
            return
        }
        inSend = true
        this.getsearchList()
        setTimeout(() => {
            inSend = false
        }, 0)

    },
    // 获取搜索数据的函数
    async getsearchList() {
        if (!this.data.searchContent) {
            this.setData({
                searchList: []
            })
            return
        }
        let { searchContent, historyList } = this.data
            // 发请求获取关键字模糊匹配数据
        let searchListData = await request('/search', { keywords: searchContent, limit: 30 })
        let search = searchListData.result.songs.slice(0, 10)
        if (searchListData.code === 405) {
            wx.showToast({
                title: '操作频繁，请稍候再试',
                icon: 'none'
            })
            return
        }
        this.setData({
            searchList: searchListData.result.songs,
            search
        })
    },
    // 清空搜索内容
    clearContent() {
        this.setData({
            searchContent: '',
            searchList: [],
            block: true,
        })
    },
    // 删除搜索的历史记录
    deleteHistory() {
        wx.showModal({
            content: '确认删除搜索记录?',
            success: (res) => {
                if (res.confirm) {
                    this.setData({
                        historyList: [],
                    })
                    wx.removeStorageSync('searchHistory')
                }
            }
        })
    },
    searchIndex(event) {
        this.setData({
            block: false
        })
    },
    toSongDetail(event) {
        let index = event.currentTarget.dataset.index
        let musicId = this.data.searchList[index].id
        let i = this.data.i
        let search = [musicId, i]

        this.setData({
            index,
        })
        wx.navigateTo({
                url: '/pages/songDetail/songDetail?musicId=' + search
            })
 
    },
    // 搜索按钮的点击事件
    toIndex() {
        if (this.data.searchContent) {
            this.setData({
                block: false
            })
        }
        let { searchContent, historyList } = this.data
                   // 将搜索的关键字添加到搜索历史记录中
                   if (historyList.indexOf(searchContent) !== -1) {
                    historyList.splice(historyList.indexOf(searchContent), 1)
                }
                historyList.unshift(searchContent)
                this.setData({
                    historyList
                })
                wx.setStorageSync('searchHistory', historyList)
    },
    // 获取焦点时触发
    bindFocus() {
        this.setData({
            block: true
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})