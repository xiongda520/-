import request from '../../utils/request'
import moment from 'moment'
import PubSub from 'pubsub-js'
// 获取全局实例
const appInstance = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        isPlay: true, //音乐是否播放
        song: {}, // 歌曲详情对象
        musicId: '', //音乐的id
        lrctimeList: [], // 音乐的歌词
        musicLink: '', //音乐的链接
        currentTime: '00:00', // 当前播放时长
        durationTime: '00:00', //总时长
        currentWidth: 0, // 实时进度条的宽度
        index: -1, // 当前默认播放歌词的下标
        i: 0, //识别页面
        handleMusi: true, // 切换播放顺序
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        // options接收路由跳转的query参数
        // 原生小程序的路由传参是有限制的，超出的会被截掉
        let music = options.musicId.split(",")
        let i = music[1]
        let musicId = music[0]
            //  获取音乐详情
        this.getMusicInfo(musicId)
            // 自动播放当前音乐
        this.musicControl(true, musicId)
        this.musicLyric(musicId)
        this.setData({
            musicId,
            i
        })
        this.getMusicInfo(musicId)
            // 判断当前页面音乐是否在播放
        if (appInstance.globalData.isMusicPlay && appInstance.globalData.musicId === musicId) {
            // 修改当前页面音乐播放状态为true
            this.setData({
                isPlay: true
            })
        }
        // 创建控制音乐播放的实例
        this.backgroundAudioManager = wx.getBackgroundAudioManager()
            // 监听音乐暂停/播放/停止
        this.backgroundAudioManager.onPlay(() => {
            this.changePlayState(true)
                // 修改全局音乐播放的状态
            appInstance.globalData.musicId = musicId
        })
        this.backgroundAudioManager.onPause(() => {
            this.changePlayState(false)
        })
        this.backgroundAudioManager.onStop(() => {
                this.changePlayState(false)
            })
            // 监听音乐播放自然结束
        this.backgroundAudioManager.onEnded(() => {
                // 自动切换下一首，并自动播放
                PubSub.subscribe('musicId', (msg, musicId) => {
                        // 取消订阅
                        PubSub.unsubscribe('musicId')
                            //  获取音乐详情
                        this.getMusicInfo(musicId)
                            // 关闭当前音乐
                        this.backgroundAudioManager.stop()
                            // 自动播放当前音乐
                        this.musicControl(true, musicId)
                        this.musicLyric(musicId)
                    })
                    // 发送消息给recommendSong页面
                let i = this.data.i
                let handleMusi = this.data.handleMusi
                if (handleMusi) {
                    switch (i) {
                        case "1":
                            PubSub.publish('search', 'naxt')
                            break;
                        case "2":
                            PubSub.publish('index', 'naxt')
                            break;

                        case "3":
                            PubSub.publish('record', 'naxt')
                            break;

                        case "4":
                            PubSub.publish('switch', 'naxt')
                            break;
                    }
                } else {
                    switch (i) {
                        case "1":
                            PubSub.publish('search', 'false')
                            break;
                        case "2":
                            PubSub.publish('index', 'false')
                            break;
                        case "3":
                            PubSub.publish('record', 'false')
                            break;
                        case "4":
                            PubSub.publish('switch', 'false')
                            break;
                    }
                }

                // 将实时进度条长度还原为0
                this.setData({
                    currentTime: '00: 00',
                    currentWidth: 0
                })
            })
            // 监听音乐实时播放的进度
        this.backgroundAudioManager.onTimeUpdate(() => {
            // 获取的时间为秒，所以要格式化
            let playTime = this.backgroundAudioManager.currentTime
            let currentTime = moment(playTime * 1000).format('mm:ss')
            let currentWidth = 450 / this.backgroundAudioManager.duration * playTime
                // 获取歌词列表
            let lrctimeList = this.data.lrctimeList
            if (this.data.index >= 3) {
                this.setData({
                    top: (this.data.index - 3) * 28
                })
            }
            for (let i = 0; i < lrctimeList.length - 1; i++) {
                if (lrctimeList[i]) {
                    if (lrctimeList[i][0] <= playTime && playTime <= lrctimeList[i + 1][0]) {
                        this.setData({
                            index: i
                        })
                    }
                }
            }
            this.setData({
                currentTime,
                currentWidth
            })
        })
    },
    // 修改播放状态的功能函数
    changePlayState(isPlay) {
        // 修改音乐是否播放的状态
        this.setData({
                isPlay
            })
            // 修改全局音乐播放的状态
        appInstance.globalData.isMusicPlay = isPlay
    },
    // 获取音乐详情的函数
    async getMusicInfo(musicId) {
        let songData = await request('/song/detail', { ids: musicId })
        let durationTime = moment(songData.songs[0].dt).format('mm:ss')
        this.setData({
                song: songData.songs[0],
                durationTime,
            })
            // 更改标题
        wx.setNavigationBarTitle({
            title: this.data.song.name
        })
    },
    // 点击播放或暂停的回调
    handleMusiPlay() {
        let isPlay = !this.data.isPlay
        let { musicId, musicLink } = this.data
        this.musicControl(isPlay, musicId, musicLink)
    },
    // 控制音乐播放/暂停的功能函数
    async musicControl(isPlay, musicId, musicLink) {
        if (isPlay) { //播放
            if (!musicLink) {
                // 获取音乐的播放链接
                let musicLinkData = await request('/song/url', { id: musicId })
                musicLink = musicLinkData.data[0].url
                if (!musicLink) {
                    // 提示用户
                    wx.showToast({
                        title: '需要开通会员哦！',
                        icon: 'none'
                    })
                    return
                }
                this.setData({
                    musicLink
                })
            }
            // 创建控制音乐播放的实例

            this.backgroundAudioManager.src = musicLink
            this.backgroundAudioManager.title = this.data.song.name
        } else { //暂停
            this.backgroundAudioManager.pause()
        }

    },
    // 获取歌词的回调
    async musicLyric(musicId) {
        let musicLyricData = await request('/lyric', { id: musicId })
        musicLyricData = musicLyricData.lrc.lyric.split("\n")
            // 最终存储数据的列表
        let lrctimeList = []
        let re = /\[\d{2}:\d{2}.\d{2,3}\]/
        for (let i = 0; i < musicLyricData.length; i++) {
            let musicData = musicLyricData[i].match(re)
            if (musicData) {
                // 拿到歌词替换字符串
                let musicLyric = musicLyricData[i].replace(re, '')
                    //拿到的时间字符串
                let musicDataTime = musicData[0]
                if (musicDataTime) {
                    // 处理时间，把分钟变成以秒为单位然后加上后面的秒数
                    //清除括号
                    musicDataTime = musicDataTime.slice(1, -1).split(':')
                        // 计算秒数
                    let time = parseFloat(musicDataTime[0]) * 60 + parseFloat(musicDataTime[1])
                    lrctimeList.push([time, musicLyric])
                }
            }

        }
        this.setData({
            lrctimeList
        })
    },
    // 点击切歌的回调
    handleSwitch(event) {
        let type = event.currentTarget.id
            // 关闭当前播放的音乐
        this.backgroundAudioManager.stop()
            // 订阅来自recommendSong页面发布的musicId
        PubSub.subscribe('musicId', (msg, musicId) => {
                //  获取音乐详情
                this.getMusicInfo(musicId)
                    // 自动播放当前音乐
                this.musicControl(true, musicId)
                this.musicLyric(musicId)
                    // 取消订阅
                PubSub.unsubscribe('musicId')
            })
            // 发送消息给recommendSong页面
        let i = this.data.i
        switch (i) {
            case "1":
                PubSub.publish('search', type)
                break;
            case "2":
                PubSub.publish('index', type)
                break;

            case "3":
                PubSub.publish('record', type)
                break;

            case "4":
                PubSub.publish('switch', type)
                break;
        }
    },
    // 随机循环的切换
    handleMusi() {
        let type = !this.data.handleMusi
        this.setData({
            handleMusi: type
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})