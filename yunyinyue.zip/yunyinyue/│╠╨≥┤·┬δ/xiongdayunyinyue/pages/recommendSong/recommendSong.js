import request from '../../utils/request'
import PubSub from 'pubsub-js'
Page({

    /**
     * 页面的初始数据
     */
    data: {
        day: '', // 天
        month: '', // 月
        recommendList: [], // 推荐列表的数据
        index: 0, //初始化音乐下标
        i: 4, // 标识页面
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        // 判断用户是否登录
        let userInfo = wx.getStorageSync('userInfo')
        if (!userInfo) {
            wx.shoToast({
                title: '请先登录',
                icon: 'none',
                success: () => {
                    wx.relauch({
                        url: '/pages/login/login'
                    })
                }
            })
        }
        // 跟新日期的状态数据
        let day = new Date().getDate()
        day = day < 10 ? '0' + day : day
        let month = new Date().getMonth() + 1
        month = month < 10 ? '0' + month : month

        this.setData({
                day,
                month
            })
            // 获取每日推荐的数据
        this.getRecommendList()
            // 订阅来自songDetail页面发布的消息
        PubSub.subscribe('switch', (msg, type) => {
            let { recommendList, index } = this.data
            if (type === 'pre') { // 上一首
                (index === 0) && (index = recommendList.length)
                index -= 1
            } else if (type === 'next') { // 下一首
                (index === recommendList.length - 1) && (index = -1)
                index += 1
            } else {
                index = this.getRandom(0, recommendList.length - 1)
            }
            // 更新下标
            this.setData({
                index
            })

            let musicId = recommendList[index].id
                // 将musicId回传给songDetail页面
            PubSub.publish('musicId', musicId)
        })
    },
    // 获取每日推荐的数据
    async getRecommendList() {
        let recommendListData = await request('/recommend/songs')
        this.setData({
            recommendList: recommendListData.recommend
        })
    },
    // 随机函数
    getRandom(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min
    },
    // 跳转至songDetail页面
    toSongDetail(event) {
        let { song, index } = event.currentTarget.dataset
        let musicId = song.id
        let i = this.data.i
        let recommendList = [musicId, i]
        this.setData({
                index
            })
            // 路由跳转传承
        wx.navigateTo({
            url: '/pages/songDetail/songDetail?musicId=' + recommendList
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})