// pages/video/video.js
import request from '../../utils/request'
Page({

    /**
     * 页面的初始数据
     */
    data: {
        videoGroupList: [], //导航的标签数据
        navId: '', //导航的标识
        videoList: [], //视频的列表数据
        videoId: '', // 视频的ID标识
        isTriggered: false, //标识下拉刷新是否被触发
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        this.getVideoGroupListData()
    },
    // 获取导航数据
    async getVideoGroupListData() {
        let videoGroupListData = await request('/video/group/list')
        this.setData({
                videoGroupList: videoGroupListData.data.slice(10, 25),
                navId: videoGroupListData.data[10].id
            })
            //获取视频列表数据
        this.getVideoList(this.data.navId)
    },
    //获取视频列表数据
    async getVideoList(navId) {
        if (!navId) { //判断navId为空的情况
            return
        }

        let videoListData = await request('/video/group', { id: navId })

        let videoList = []
        for (let i = 0; i < videoListData.datas.length; i++) {
            let vId = videoListData.datas[i].data.vid
            let videoListVid = await request('/video/url', { id: vId })
            let videoItem = {
                id: videoListVid.urls[0].id,
                imgId: i,
                url: videoListVid.urls[0].url,
                title: videoListData.datas[i].data.title,
                nickname: videoListData.datas[i].data.creator.nickname,
                praisedCount: videoListData.datas[i].data.praisedCount,
                commentCount: videoListData.datas[i].data.commentCount,
                avatarUrl: videoListData.datas[i].data.creator.avatarUrl,
                coverUrl: videoListData.datas[i].data.coverUrl,
            }
            videoList.push(videoItem)
        }
        wx.hideLoading()

        this.setData({
            videoList,
            isTriggered: false //关闭下拉刷新
        })

    },

    // 点击切换导航的回调
    changeNav(event) {
        let navId = event.currentTarget.id
        this.setData({
                navId: navId * 1,
                videoList: []
            })
            // 显示加载
        wx.showLoading({
                title: '正在加载'
            })
            // 动态获取当前导航对应的视频数据
        this.getVideoList(this.data.navId)
    },
    // 点击播放/继续播放的回调
    handlePlay(event) {
        let vid = event.currentTarget.id
            // 更新data中videoId的状态数据
        this.setData({
            videoId: vid
        })


        //创建控制video标签的实例对象
        this.videoContext = wx.createVideoContext(vid)

    },
    //自定义下拉刷新回调：scroll-view
    handleRefresher() {
        this.getVideoList(this.data.navId)
    },
    //跳转到搜索界面
    toSearch() {
        wx.navigateTo({
            url: '/pages/search/search',
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function({ from }) {
        if (from === 'button') {
            return {
                title: '分享给微信好友',
                page: '/pages/video/video',
                imageUrl: '/static/images/iu1.jpeg'
            }
        } else {
            return {
                title: '分享给微信好友',
                page: '/pages/video/video',
                imageUrl: '/static/images/iu1.jpeg'
            }
        }

    }
})