import request from '../../utils/request'
Page({

    /**
     * 页面的初始数据
     */
    data: {
        singerList: [], //热门歌手列表
        singerMvList: [], //MV列表数据
        videoId: '', //视频的Id标识
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        this.getsingerList()
    },
    async getsingerList() {
        let singerList = this.data.singerList
        for (let i = 0; i < 10; i++) {
            let singerListData = await request('/top/artists', { offset: 0, limit: 10 })
            let singerLists = {
                name: singerListData.artists[i].name,
                id: singerListData.artists[i].id,
                picUrl: singerListData.artists[i].picUrl,
                alias: singerListData.artists[i].alias[0]
            }
            singerList.push(singerLists)
        }
        this.setData({
            singerList
        })
        for (let i = 0; i < singerList.length; i++) {
            let singerMvListData = await request('/artist/mv', { id: singerList[i].id })
            let singerMvList = this.data.singerMvList
            let singer = []
            for (let j = 0; j < singerMvListData.mvs.length; j++) {
                let mvListData = await request('/mv/url', { id: singerMvListData.mvs[j].id })
                let singerListMv = {
                    id: singerMvListData.mvs[j].id,
                    name: singerMvListData.mvs[j].name,
                    imgurl: singerMvListData.mvs[j].imgurl,
                    url: mvListData.data.url
                }
                singer.push(singerListMv)
            }
            singerMvList.push(singer)
            this.setData({
                singerMvList
            })

        }

    },
    // 点击播放和继续播放的回调
    handlePlay(event) {
        let vid = event.currentTarget.id
            // 更新data中videoId的状态
        this.setData({
            videoId: vid
        })
        this.videoContext = wx.createVideoContext(vid)
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})