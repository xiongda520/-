// pages/index/index.js
import request from '../../utils/request'
import PubSub from 'pubsub-js'
Page({

    /**
     * 页面的初始数据
     */
    data: {
        bannerList: [], //初始话banner轮播图数据
        indexList: [], // 推荐歌单数据初始化 
        fmList: [], // 私人Fm列表数据
        topList: [], //排行榜数据初始化
        item: 0, //排行榜下标
        index: 0, //初始化音乐下标
        i: 2, //标识页面
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: async function(options) {
        this.getfmList()
            // 轮播图数据请求
        let bannerListData = await request('/banner', { type: 2 })
        this.setData({
            bannerList: bannerListData.banners
        })

        // 获取推荐歌单数据
        let recommendListData = await request('/personalized/newsong', { limit: 10 })
        this.setData({
                indexList: recommendListData.result
            })
            //获取排行榜数据
        let i = 0;
        let resultArr = [];
        while (i < 4) {
            let topListData = await request('/top/list', { idx: i++ });
            // splice(会修改原数组，可以对指定的数组进行增删改) slice(不会修改原数组)
            let topListItem = { name: topListData.playlist.name, tracks: topListData.playlist.tracks.slice(0, 3) };
            resultArr.push(topListItem);
            // 不需要等待五次请求全部结束才更新，用户体验较好，但是渲染次数会多一些
            this.setData({
                topList: resultArr
            })
        }
    },
    async getfmList() {
        let fmList = await request('/personal_fm')
        this.setData({
            fmList: fmList.data
        })
    },
    // 订阅来自songDetail页面发布的消息
    getsongDetail(list) {

        PubSub.subscribe('index', (msg, type) => {
            if (this.tap) {
                let index = this.data.index
                if (type === 'pre') { // 上一首
                    (index === 0) && (index = list.length)
                    index -= 1
                } else if (type === 'next') { // 下一首
                    (index === list.length - 1) && (index = -1)
                    index += 1
                } else {
                    index = this.getRandom(0, list.length - 1)
                }
                // 更新下标
                this.setData({
                    index
                })
                let musicId = list[index].id
                    // 将musicId回传给songDetail页面
                PubSub.publish('musicId', musicId)
            } else {
                let index = this.data.index
                let fmList = this.data.fmList
                if (type === 'pre') { // 上一首
                    (index === 0) && (index = fmList.length)
                    index -= 1
                } else if (type === 'next') { // 下一首
                    (index === fmList.length - 1) && (index = -1)
                    index += 1
                } else {
                    index = this.getRandom(0, fmList.length - 1)
                }
                // 更新下标
                this.setData({
                    index
                })
                let musicId = fmList[index].id
                    // 将musicId回传给songDetail页面
                PubSub.publish('musicId', musicId)
            }
        })

    },
    // 随机函数
    getRandom(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min
    },
    // 跳转至RecommendSong页面的回调
    toRecommendSong() {
        wx.navigateTo({
            url: '/pages/recommendSong/recommendSong'
        })
    },
    toSearch() {
        wx.navigateTo({
            url: '/pages/search/search',
        })
    },
    // 推荐歌单歌曲播放
    recommedContainer(event) {
        this.tap = true
        let index = event.currentTarget.dataset.index
        let indexList = this.data.indexList
        let musicId = indexList[index].id
        let i = this.data.i
        let inde = [musicId, i]
        this.setData({
            index
        })
        wx.navigateTo({
            url: '/pages/songDetail/songDetail?musicId=' + inde
        })
        this.getsongDetail(indexList)
    },
    // 排行榜歌曲播放
    musicItemContainer(event) {
        let item = event.currentTarget.dataset.item
        let index = event.currentTarget.dataset.index
        let musicId = this.data.topList[item].tracks[index].id
        let i = this.data.i
        let inde = [musicId, i]
        wx.navigateTo({
            url: '/pages/songDetail/songDetail?musicId=' + inde
        })
    },
    // 电台点击事件
    fmItem() {
        this.tap = false
        let fmList = this.data.fmList
        let index = 0
        let musicId = fmList[index].id
        let i = this.data.i
        let inde = [musicId, i]
        wx.navigateTo({
            url: '/pages/songDetail/songDetail?musicId=' + inde
        })
    },
    singerMv() {
        wx.navigateTo({
            url: '/pages/singer/singer'
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})