import request from '../../utils/request'
import PubSub from 'pubsub-js'
Page({

    /**
     * 页面的初始数据
     */
    data: {
        recordList: [], // 推荐列表的数据
        index: 0, //初始化音乐下标
        i: 3, //标识页面
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let userId = options.userId
            // 判断用户是否登录
        let userInfo = wx.getStorageSync('userInfo')
        if (!userInfo) {
            wx.shoToast({
                title: '请先登录',
                icon: 'none',
                success: () => {
                    wx.relauch({
                        url: '/pages/login/login'
                    })
                }
            })
        }
        // 获取每日推荐的数据
        this.getRecommendList(userId)
            // 订阅来自songDetail页面发布的消息
        let index = this.data.index

        PubSub.subscribe('record', (msg, type) => {
            let recordList = this.data.recordList
            if (type === 'pre') { // 上一首
                (index === 0) && (index = recordList.length)
                index -= 1
            } else if (type === 'next') { // 下一首
                (index === recordList.length - 1) && (index = -1)
                index += 1
            } else {
                index = this.getRandom(0, recordList.length - 1)
            }

            // 更新下标
            this.setData({
                index
            })
            let musicId = recordList[index].song.id
                // 将musicId回传给songDetail页面
            PubSub.publish('musicId', musicId)
        })
    },
    // 获取每日推荐的数据
    async getRecommendList(userId) {
        let recommendListData = await request('/user/record', { uid: userId, type: 0 })
        this.setData({
            recordList: recommendListData.allData.splice(0, 30)
        })
    },
    // 随机函数
    getRandom(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min
    },
    // 跳转至songDetail页面
    toSongDetail(event) {
        let musicId = event.currentTarget.dataset.song.song.id
        let index = event.currentTarget.dataset.index
        let i = this.data.i
        let record = [musicId, i]
        this.setData({
                index
            })
            // 路由跳转传承
        wx.navigateTo({
            url: '/pages/songDetail/songDetail?musicId=' + record
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})